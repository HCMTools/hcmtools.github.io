/* =============== TIỆN ÍCH IN/LƯU PNG PHIẾU KHO (SOFT UI) =============== */
/* Ghi chú (tiếng Việt):
   - Tự ẩn cụm nút sau 5 giây không tương tác; hiện lại khi bấm nút mũi tên.
   - Nút “In nhanh” in đúng khổ 100×150mm (dùng @page).
   - “Lưu PNG” sao chép ảnh vào Clipboard; nếu tick “Tải ảnh” thì tải về.
   - Lấy đúng “Số chứng từ” (NK…/XK…) & “Ngày chứng từ”.
   - SL: bỏ dấu ngăn cách và bỏ đuôi “000” mặc định của AMIS.
*/

function toast(msg){
  let t = document.getElementById('amis-kho-toast');
  if(!t){ t=document.createElement('div'); t.id='amis-kho-toast'; document.body.appendChild(t); }
  t.textContent = msg; t.classList.add('show'); clearTimeout(toast._timer);
  toast._timer=setTimeout(()=>t.classList.remove('show'), 1600);
}

/* ---------- Ẩn/hiện cụm nút ---------- */
let autoTimer=null;
function scheduleAutoHide(){
  clearTimeout(autoTimer);
  autoTimer=setTimeout(()=>{
    const fab=document.getElementById('amis-kho-fab');
    if(fab) fab.classList.add('ak-hidden');
  }, 5000);
}
function showFab(){
  const fab=document.getElementById('amis-kho-fab');
  if(fab) fab.classList.remove('ak-hidden');
  scheduleAutoHide();
}

/* ---------- Giao diện (3 nút) + nút mũi tên ---------- */
function injectUI(){
  if(document.getElementById('amis-kho-fab')) return;

  // Nút mũi tên
  const tgl = document.createElement('button');
  tgl.id='ak-toggle';
  tgl.title='Hiện/ẩn công cụ phiếu kho';
  tgl.innerHTML=`<svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg>`; // mũi tên >
  tgl.addEventListener('click', ()=>{
    const fab=document.getElementById('amis-kho-fab');
    if(!fab) return;
    if(fab.classList.contains('ak-hidden')){ fab.classList.remove('ak-hidden'); scheduleAutoHide(); }
    else { fab.classList.add('ak-hidden'); }
  });
  document.body.appendChild(tgl);

  // Cụm nút
  const wrap = document.createElement('div');
  wrap.id = 'amis-kho-fab';
  wrap.innerHTML = `
    <button id="ak-btn-print" class="btn secondary" title="In nhanh">In nhanh</button>
    <button id="ak-btn-export" class="btn" title="Lưu PNG + copy vào Clipboard">Lưu phiếu PNG</button>
    <label class="chk"><input type="checkbox" id="ak-save-file"> Tải ảnh</label>
  `;
  document.body.appendChild(wrap);

  document.getElementById('ak-btn-export').addEventListener('click', ()=>{runExport(); showFab();});
  document.getElementById('ak-btn-print').addEventListener('click', ()=>{runPrint(); showFab();});
  wrap.addEventListener('mousemove', scheduleAutoHide);
  wrap.addEventListener('mouseenter', showFab);

  // Lần đầu xuất hiện rồi tự ẩn sau 5s
  showFab();
}

/* ---------- Tìm input gần label (ưu tiên cùng container) ---------- */
function findInputNearLabel(regex){
  const cands = Array.from(document.querySelectorAll('label, .label, span, div')).filter(el=>regex.test((el.textContent||'').trim()));
  for(const el of cands){
    let box = el.closest('div');
    for(let up=0; up<3 && box; up++){
      const input = box.querySelector('input[type="text"], input[type="date"], input, [contenteditable="true"]');
      if(input && (input.value || input.textContent)) return input;
      box = box.parentElement;
    }
    const sib = el.nextElementSibling && el.nextElementSibling.querySelector && el.nextElementSibling.querySelector('input');
    if(sib) return sib;
  }
  return null;
}

/* ---------- Tìm bảng Hàng tiền ---------- */
function findGoodsTable(){
  const tables = Array.from(document.querySelectorAll('table'));
  for(const tb of tables){
    const ths = Array.from(tb.querySelectorAll('thead th')).map(el=>el.textContent.trim());
    const ok = ths.some(t=>/Mã hàng/i.test(t)) && ths.some(t=>/Tên hàng/i.test(t)) && ths.some(t=>/Số lượng/i.test(t));
    if(ok) return tb;
  }
  for(const tb of tables){
    const text = tb.textContent;
    if(/Mã hàng/i.test(text) && /Số lượng/i.test(text)) return tb;
  }
  return null;
}

/* ---------- Meta: Số CT (NK/XK...) & Ngày chứng từ ---------- */
function readMeta(){
  let soct = '', ngayct = '';

  const soctInput = findInputNearLabel(/^\s*Số\s*chứng\s*từ\s*$/i);
  if(soctInput) soct = (soctInput.value || soctInput.textContent || '').trim();
  const mCT = (soct || document.body.innerText).match(/\b([NX]K[0-9\-\/\.]+)\b/i);
  if(mCT) soct = mCT[1].toUpperCase(); else soct='';

  const ngayInput = findInputNearLabel(/^\s*Ngày\s*chứng\s*từ\s*$/i);
  if(ngayInput) ngayct = (ngayInput.value || ngayInput.textContent || '').trim();
  if(/^\d{4}-\d{2}-\d{2}$/.test(ngayct)){ const [y,m,d]=ngayct.split('-'); ngayct = `${d}/${m}/${y}`; }
  if(!/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(ngayct)){
    const m = document.body.innerText.match(/\b(\d{1,2}\/\d{1,2}\/\d{4})\b/);
    if(m) ngayct = m[1];
  }
  return {soct, ngayct};
}

/* ---------- Chuẩn hoá Số lượng ---------- */
function normalizeSL(s){
  s = (s || '').trim();
  if(!s) return '';

  // Chuẩn VN: "," là thập phân | "." là phân cách nghìn
  if (s.includes(',')) {
    // bỏ dấu phân cách nghìn
    s = s.replace(/\./g, '');

    const num = parseFloat(s.replace(',', '.'));
    if (isNaN(num)) return s;

    // 25,000 → 25
    if (Number.isInteger(num)) return String(num);

    // 28,8 → 28,8 | 12,500 → 12,5
    return s.replace(/0+$/, '').replace(/,$/, '');
  }

  // Không có dấu phẩy → số nguyên
  s = s.replace(/\./g, '');

  // AMIS thường trả 25000 cho 25
  if (/^\d+000$/.test(s)) {
    return String(parseInt(s, 10) / 1000);
  }

  return s;
}


/* ---------- Lấy dữ liệu bảng ---------- */
function scrapeData(){
  const tb = findGoodsTable();
  if(!tb){ toast('Không tìm thấy bảng Hàng tiền.'); return null; }
  const head = Array.from(tb.querySelectorAll('thead th')).map(el=>el.textContent.trim());
  const col = {
    stt: head.findIndex(h=>/^#$/i.test(h) || /STT/i.test(h)),
    ma: head.findIndex(h=>/Mã hàng/i.test(h)),
    ten: head.findIndex(h=>/Tên hàng/i.test(h)),
    dvt: head.findIndex(h=>/ĐVT|Đơn vị/i.test(h)),
    sl: head.findIndex(h=>/Số lượng/i.test(h)),
  };
  const rows = [];
  tb.querySelectorAll('tbody tr').forEach(tr=>{
    const tds = tr.querySelectorAll('td');
    const get = (i)=> i>=0 && i<tds.length ? tds[i].innerText.trim() : '';
    const stt = get(col.stt) || String(rows.length+1);
    const ma  = get(col.ma);
    const ten = get(col.ten);
    const dvt = get(col.dvt);
    const sl  = normalizeSL(get(col.sl));
    if(ten || ma) rows.push({stt,ten,ma,dvt,sl});
  });
  const meta = readMeta();
  return {rows, meta};
}

/* ---------- Vẽ PNG (Soft UI, 100mm chiều rộng) ---------- */
function mmToPx(mm, dpi){ dpi=dpi||96; return Math.round(mm*dpi/25.4); }
function width(ctx, s){ return ctx.measureText(s).width; }
function wrapSmart(ctx, text, maxW){
  text = (text||'').trim(); if(!text) return [''];
  const tokens = text.split(/(\-|\/|_|\s+)/).filter(Boolean);
  const lines=[]; let line='';
  for(const t of tokens){
    const test = line + t;
    if(width(ctx,test) <= maxW){ line = test; } else {
      if(line.trim()) lines.push(line.trim()); line='';
      if(width(ctx,t) > maxW){
        let chunk=''; for(const ch of t){ const tryc=chunk+ch; if(width(ctx,tryc)<=maxW) chunk=tryc; else { lines.push(chunk); chunk=ch; } }
        line = chunk;
      } else line = t;
    }
  }
  if(line.trim()) lines.push(line.trim()); return lines;
}

function buildCanvas(payload){
  const {rows, meta} = payload;
  const isXK = /^XK/i.test(meta.soct||'');
  const title = isXK ? 'PHIẾU XUẤT KHO' : 'PHIẾU NHẬP KHO';
  const ngay = meta.ngayct || new Date().toLocaleDateString('vi-VN');
  const soct = meta.soct || '';

  const scale=3, baseW=mmToPx(100,96), contentW=baseW*scale;
  const outer=12*scale, cardPad=10*scale, rSheet=12*scale;
  const padL=10*scale, padR=10*scale, padT=10*scale, padB=10*scale;
  const lineW=Math.max(1,Math.floor(scale));
  const colPerc=[.10,.50,.15,.10,.15];

  const test=document.createElement('canvas').getContext('2d');
  test.font=(12*scale)+'px Arial, sans-serif';
  const Wdraw = contentW - padL - padR;
  const colX=[padL]; for(let i=0;i<5;i++) colX.push(colX[i]+Math.floor(Wdraw*colPerc[i]));
  const headerH=18*scale, metaH=16*scale, gap=6*scale, thH=24*scale, rowPadY=6*scale, lineH=14*scale;
  const maxTenW=colX[2]-colX[1]-8*scale, maxMaW=colX[3]-colX[2]-8*scale;

  let contentH = padT + headerH + gap + metaH + gap + thH;
  for(const r of rows){
    const n = Math.max(wrapSmart(test,r.ten,maxTenW).length, wrapSmart(test,r.ma,maxMaW).length, 1);
    const h = rowPadY*2 + n*lineH; contentH += h;
  }
  contentH += padB;

  const W = contentW + (outer+cardPad)*2;
  const H = contentH + (outer+cardPad)*2;

  const canvas=document.createElement('canvas'); canvas.width=W; canvas.height=H;
  const c=canvas.getContext('2d');

  const grad=c.createLinearGradient(0,0,0,H); grad.addColorStop(0,'#f7f9ff'); grad.addColorStop(1,'#eaf1ff');
  c.fillStyle=grad; c.fillRect(0,0,W,H);

  function rrect(ctx,x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}

  const cardX=outer, cardY=outer, cardW=W-outer*2, cardH=H-outer*2;
  c.shadowColor='rgba(0,0,0,.18)'; c.shadowBlur=18*scale; c.shadowOffsetY=8*scale;
  c.fillStyle='#eef3fb'; rrect(c,cardX,cardY,cardW,cardH,rSheet); c.fill(); c.shadowColor='transparent';

  const sheetX=cardX+cardPad, sheetY=cardY+cardPad, sheetW=contentW, sheetH=contentH;
  c.fillStyle='#fff'; rrect(c,sheetX,sheetY,sheetW,sheetH,rSheet); c.fill();
  c.strokeStyle='#d4dae7'; c.lineWidth=1*scale; rrect(c,sheetX+0.5,sheetY+0.5,sheetW-1,sheetH-1,rSheet); c.stroke();

  const ox=sheetX, oy=sheetY; c.save(); c.translate(0.5,0.5); c.strokeStyle='#000'; c.lineWidth=lineW; c.fillStyle='#000';

  // Đậm các phần cần đậm
  c.font='700 '+(14*scale)+'px Arial, sans-serif'; c.textAlign='center'; c.textBaseline='top';
  c.fillText(title, ox+contentW/2, oy+padT);

  c.textAlign='left'; c.font='400 '+(12*scale)+'px Arial, sans-serif';
  c.fillText('Ngày: ', ox+padL, oy+padT+headerH+gap);
  c.font='700 '+(12*scale)+'px Arial, sans-serif'; c.fillText(ngay, ox+padL+width(c,'Ngày: '), oy+padT+headerH+gap);

  c.textAlign='right'; c.font='400 '+(12*scale)+'px Arial, sans-serif';
  const label='Số phiếu: ';
  c.fillText(label, ox+contentW-padR-width(c,label+soct)+width(c,label), oy+padT+headerH+gap);
  c.font='700 '+(12*scale)+'px Arial, sans-serif'; c.fillText(soct, ox+contentW-padR, oy+padT+headerH+gap);

  // Header bảng
  let ty= oy+padT+headerH+gap+metaH+gap;
  c.fillStyle='#f1f5f9'; c.fillRect(Math.floor(ox+padL), Math.floor(ty), Math.floor(Wdraw), Math.floor(thH));
  c.fillStyle='#000'; c.textAlign='center'; c.textBaseline='middle';
  c.font='700 '+(12*scale)+'px Arial, sans-serif';
  const ths=['STT','Tên hàng','Mã','ĐVT','SL'];
  for(let i=0;i<5;i++){
    const x0=Math.floor(ox+colX[i]), x1=Math.floor(ox+colX[i+1]);
    c.strokeRect(x0, Math.floor(ty), x1-x0, Math.floor(thH));
    c.fillText(ths[i], Math.floor((x0+x1)/2), Math.floor(ty+thH/2));
  }
  ty += thH; c.textBaseline='top';

  // Dòng
  for(const r of rows){
    const n = Math.max(wrapSmart(c,r.ten,maxTenW).length, wrapSmart(c,r.ma,maxMaW).length, 1);
    const rh = rowPadY*2 + n*lineH;

    for(let i=0;i<5;i++){
      const x0=Math.floor(ox+colX[i]), x1=Math.floor(ox+colX[i+1]);
      c.strokeRect(x0, Math.floor(ty), x1-x0, Math.floor(rh));
    }

    c.textAlign='center'; c.font='400 '+(12*scale)+'px Arial, sans-serif';
    c.fillText(r.stt, Math.floor(ox+(colX[0]+colX[1])/2), Math.floor(ty + (rh-14*scale)/2));

    c.textAlign='left';
    let y = ty + 6*scale;
    wrapSmart(c, r.ten, maxTenW).forEach(line=>{ c.fillText(line, Math.floor(ox + colX[1] + 4*scale), Math.floor(y)); y += 14*scale; });

    y = ty + 6*scale;
    wrapSmart(c, r.ma, maxMaW).forEach(line=>{ c.fillText(line, Math.floor(ox + colX[2] + 4*scale), Math.floor(y)); y += 14*scale; });

    c.textAlign='center';
    c.fillText(r.dvt, Math.floor(ox+(colX[3]+colX[4])/2), Math.floor(ty + (rh-14*scale)/2));
    c.fillText(r.sl, Math.floor(ox+(colX[4]+colX[5])/2), Math.floor(ty + (rh-14*scale)/2));

    ty += rh;
  }

  c.restore();
  return canvas;
}

/* ---------- Lưu PNG (copy Clipboard + tùy chọn tải file) ---------- */
async function runExport(){
  const payload = scrapeData(); if(!payload) return;
  const canvas = buildCanvas(payload);
  const blob = await new Promise(res=>canvas.toBlob(res,'image/png'));

  // Copy vào clipboard
  try{
    if(navigator.clipboard && window.ClipboardItem){
      await navigator.clipboard.write([new ClipboardItem({"image/png": blob})]);
    }
  }catch(e){}

  // Tải về nếu chọn
  if(document.getElementById('ak-save-file').checked){
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const ts = new Date().toISOString().slice(0,19).replace(/[T:]/g,'-');
    a.href = url; a.download = 'PhieuKho_'+ts+'.png';
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    toast('✅ Đã tải & sao chép ảnh');
  }else{
    toast('✅ Đã sao chép ảnh');
  }
}

/* ---------- In nhanh đúng 100×150mm ---------- */
async function runPrint(){
  const payload = scrapeData(); if(!payload) return;
  const canvas = buildCanvas(payload);
  const dataUrl = canvas.toDataURL('image/png');

  const w = window.open('', '_blank', 'width=520,height=820');
  w.document.write(`
    <html><head><title>In phiếu</title>
    <style>
      @page { size: 100mm 150mm; margin: 0; }
      html,body{ height:100%; }
      body{ margin:0; display:flex; justify-content:center; align-items:center; background:#f0f3f9; }
      img{ width:100mm; height:auto; image-rendering:-webkit-optimize-contrast; }
    </style>
    </head><body><img src="${dataUrl}"/></body></html>
  `);
  w.document.close(); w.focus(); w.onload = ()=> w.print();
}

/* ---------- Khởi tạo ---------- */
(function init(){ injectUI(); })();
