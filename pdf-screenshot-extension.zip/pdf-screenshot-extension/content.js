// content.js - PDF Screenshot Tool

(function () {
  'use strict';

  // Chỉ inject 1 lần
  if (window.__pdfSnipInjected) return;
  window.__pdfSnipInjected = true;

  let snipBtn = null;
  let overlay = null;
  let selectionEl = null;
  let sizeLabel = null;
  let isSelecting = false;
  let startX = 0, startY = 0;
  let currentX = 0, currentY = 0;
  let screenshotData = null;
  let imgCounter = 0;

  // ──────────────────────────────────────────
  // Kiểm tra có phải PDF không
  // ──────────────────────────────────────────
  function isPDFPage() {
    const url = window.location.href.toLowerCase();
    const ct = document.contentType || '';
    return url.endsWith('.pdf') ||
           url.includes('.pdf?') ||
           url.includes('/pdf/') ||
           ct === 'application/pdf' ||
           document.querySelector('embed[type="application/pdf"]') !== null ||
           document.querySelector('object[type="application/pdf"]') !== null ||
           document.title.toLowerCase().endsWith('.pdf') ||
           document.body?.id === 'webkit-pdf-container';
  }

  // ──────────────────────────────────────────
  // Tạo nút Cắt Ảnh
  // ──────────────────────────────────────────
  function createSnipButton() {
    if (snipBtn) return;

    snipBtn = document.createElement('button');
    snipBtn.id = 'pdf-snip-btn';
    snipBtn.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M6 2v20M18 2v20M2 12h20M2 6h4M18 6h4M2 18h4M18 18h4"/>
      </svg>
      Cắt Ảnh
    `;
    snipBtn.title = 'Cắt & Lưu ảnh từ PDF';
    snipBtn.addEventListener('click', startSnipping);
    document.body.appendChild(snipBtn);
  }

  // ──────────────────────────────────────────
  // Bắt đầu chế độ cắt ảnh
  // ──────────────────────────────────────────
  function startSnipping() {
    screenshotData = null;

    // Chụp màn hình trước khi overlay che
    chrome.runtime.sendMessage({ action: 'captureTab' }, (res) => {
      if (!res || !res.success) {
        showToast('❌ Không thể chụp màn hình', false);
        return;
      }
      screenshotData = res.dataUrl;
      showSelectionOverlay();
    });
  }

  // ──────────────────────────────────────────
  // Hiện overlay để chọn vùng
  // ──────────────────────────────────────────
  function showSelectionOverlay() {
    // Overlay nền tối
    overlay = document.createElement('div');
    overlay.id = 'snip-overlay';
    overlay.innerHTML = `
      <div class="snip-hint">
        ✂ Kéo để chọn vùng cần cắt
        <span>Nhấn ESC để hủy</span>
      </div>
    `;
    document.body.appendChild(overlay);

    // Vùng selection
    selectionEl = document.createElement('div');
    selectionEl.id = 'snip-selection';
    selectionEl.style.display = 'none';
    document.body.appendChild(selectionEl);

    // Label hiển thị kích thước
    sizeLabel = document.createElement('div');
    sizeLabel.id = 'snip-size-label';
    sizeLabel.style.display = 'none';
    document.body.appendChild(sizeLabel);

    // Events
    overlay.addEventListener('mousedown', onMouseDown);
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
    document.addEventListener('keydown', onKeyDown);
  }

  function onMouseDown(e) {
    e.preventDefault();
    isSelecting = true;
    startX = e.clientX;
    startY = e.clientY;
    currentX = e.clientX;
    currentY = e.clientY;

    selectionEl.style.display = 'block';
    updateSelection();

    // Ẩn hint
    const hint = overlay.querySelector('.snip-hint');
    if (hint) hint.style.display = 'none';
  }

  function onMouseMove(e) {
    if (!isSelecting) return;
    currentX = e.clientX;
    currentY = e.clientY;
    updateSelection();

    // Update size label
    const w = Math.abs(currentX - startX);
    const h = Math.abs(currentY - startY);
    sizeLabel.textContent = `${Math.round(w)} × ${Math.round(h)}`;
    sizeLabel.style.display = 'block';
    sizeLabel.style.left = (Math.min(startX, currentX)) + 'px';
    sizeLabel.style.top = (Math.min(startY, currentY) - 24) + 'px';
  }

  function onMouseUp(e) {
    if (!isSelecting) return;
    isSelecting = false;
    currentX = e.clientX;
    currentY = e.clientY;

    const w = Math.abs(currentX - startX);
    const h = Math.abs(currentY - startY);

    if (w < 10 || h < 10) {
      // Vùng quá nhỏ, hủy
      cancelSnipping();
      return;
    }

    finishCrop();
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') {
      cancelSnipping();
    }
  }

  function updateSelection() {
    const x = Math.min(startX, currentX);
    const y = Math.min(startY, currentY);
    const w = Math.abs(currentX - startX);
    const h = Math.abs(currentY - startY);

    selectionEl.style.left = x + 'px';
    selectionEl.style.top = y + 'px';
    selectionEl.style.width = w + 'px';
    selectionEl.style.height = h + 'px';
  }

  // ──────────────────────────────────────────
  // Cắt ảnh từ screenshot
  // ──────────────────────────────────────────
  function finishCrop() {
    const x = Math.min(startX, currentX);
    const y = Math.min(startY, currentY);
    const w = Math.abs(currentX - startX);
    const h = Math.abs(currentY - startY);
    const dpr = window.devicePixelRatio || 1;

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img,
        x * dpr, y * dpr, w * dpr, h * dpr,
        0, 0, w * dpr, h * dpr
      );
      const croppedUrl = canvas.toDataURL('image/png');
      cleanupOverlay();
      showPreview(croppedUrl);
    };
    img.src = screenshotData;
  }

  // ──────────────────────────────────────────
  // Hiện preview
  // ──────────────────────────────────────────
  function showPreview(dataUrl) {
    const modal = document.createElement('div');
    modal.id = 'snip-preview-modal';

    const now = new Date();
    const dateStr = `${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;

    modal.innerHTML = `
      <div id="snip-preview-box">
        <div id="snip-preview-header">
          <div class="snip-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <path d="m21 15-5-5L5 21"/>
            </svg>
            Xem Trước
          </div>
          <span style="color:rgba(255,255,255,0.35);font-size:12px;font-family:'Segoe UI Mono',monospace">
            ${dateStr}.png
          </span>
        </div>
        <div id="snip-preview-img-wrap">
          <img id="snip-preview-img" src="${dataUrl}" alt="Ảnh đã cắt" />
        </div>
        <div id="snip-preview-footer">
          <button class="snip-btn snip-btn-retake" id="snip-retake-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/>
              <path d="M3 3v5h5"/>
            </svg>
            Chụp Lại
          </button>
          <button class="snip-btn snip-btn-save" id="snip-save-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            Lưu Ảnh
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    document.getElementById('snip-save-btn').addEventListener('click', () => {
      imgCounter++;
      const filename = `screenshot_${dateStr}_${String(imgCounter).padStart(3,'0')}.png`;
      chrome.runtime.sendMessage({ action: 'saveImage', dataUrl, filename }, (res) => {
        modal.remove();
        if (res && res.success) {
          showToast('✅ Đã lưu vào Pictures!', true);
        } else {
          showToast('❌ Lưu thất bại!', false);
        }
      });
    });

    document.getElementById('snip-retake-btn').addEventListener('click', () => {
      modal.remove();
      startSnipping();
    });

    // Click ngoài để đóng
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.remove();
    });

    // ESC để đóng
    const escHandler = (e) => {
      if (e.key === 'Escape') {
        modal.remove();
        document.removeEventListener('keydown', escHandler);
      }
    };
    document.addEventListener('keydown', escHandler);
  }

  // ──────────────────────────────────────────
  // Helpers
  // ──────────────────────────────────────────
  function cancelSnipping() {
    isSelecting = false;
    cleanupOverlay();
  }

  function cleanupOverlay() {
    if (overlay) { overlay.remove(); overlay = null; }
    if (selectionEl) { selectionEl.remove(); selectionEl = null; }
    if (sizeLabel) { sizeLabel.remove(); sizeLabel = null; }
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);
    document.removeEventListener('keydown', onKeyDown);
  }

  function pad(n) {
    return String(n).padStart(2, '0');
  }

  function showToast(msg, success = true) {
    const old = document.getElementById('snip-toast');
    if (old) old.remove();

    const toast = document.createElement('div');
    toast.id = 'snip-toast';
    toast.innerHTML = msg;
    toast.style.borderLeftColor = success ? '#00d084' : '#e94560';
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('hide');
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }

  // ──────────────────────────────────────────
  // Init
  // ──────────────────────────────────────────
  function init() {
    createSnipButton(); // Luôn hiện nút - dùng được mọi trang
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Lắng nghe message từ popup
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'triggerSnip') {
      startSnipping();
    }
  });

})();
