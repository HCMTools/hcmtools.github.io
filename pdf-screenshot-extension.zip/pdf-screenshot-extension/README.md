# 📸 PDF Screenshot Tool - Chrome Extension

Cắt & lưu ảnh từ PDF nhanh, không hỏi đường dẫn.

## ⚡ Cách cài đặt

1. **Giải nén** file zip vào 1 thư mục (ví dụ: `C:\Tools\pdf-screenshot-extension`)

2. **Mở Chrome** → Gõ vào thanh địa chỉ: `chrome://extensions`

3. **Bật Developer mode** (góc trên phải, gạt công tắc sang ON)

4. Nhấn **"Load unpacked"** → chọn thư mục vừa giải nén

5. Extension đã sẵn sàng! ✅

---

## 🎯 Cách dùng

### Cách 1 - Nút nổi (khuyên dùng)
- Mở bất kỳ file PDF nào trong Chrome
- Nhìn góc **phải dưới** màn hình → có nút **"✂ Cắt Ảnh"** màu đỏ
- Nhấn nút → kéo chuột chọn vùng cần cắt
- Xem preview → nhấn **"Lưu Ảnh"**

### Cách 2 - Từ popup extension
- Nhấn icon extension trên thanh công cụ Chrome
- Nhấn **"Bắt Đầu Cắt Ảnh"**

---

## 💾 File được lưu ở đâu?

Ảnh tự động lưu vào:
```
Downloads\Pictures\screenshot_YYYYMMDD_HHMMSS_001.png
```

Không hỏi đường dẫn, không popup xác nhận → chụp liên tục siêu nhanh!

---

## ⌨️ Phím tắt

| Phím | Chức năng |
|------|-----------|
| `ESC` | Hủy đang cắt / Đóng preview |
| Kéo chuột | Chọn vùng cần chụp |
| Click ngoài | Đóng preview |

---

## 📁 Cấu trúc file

```
pdf-screenshot-extension/
├── manifest.json      # Cấu hình extension
├── background.js      # Xử lý lưu file & chụp màn hình
├── content.js         # Giao diện cắt ảnh
├── content.css        # Style
├── popup.html         # Popup khi click icon
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```
